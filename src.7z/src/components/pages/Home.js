import React from 'react';
import HeroSection from '../pages/HeroSection';

function Home() {
  
  return (
    <div>
    
      <HeroSection/>
    </div>
  )
}

export default Home;
