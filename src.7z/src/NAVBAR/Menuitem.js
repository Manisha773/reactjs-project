const Menuitem = [
    {
      title: 'Beginner',
      path: '/beginner',
      cName: 'dropdown-link'
    },
    {
      title: 'Intermediate',
      path: '/intermediate',
      cName: 'dropdown-link'
    },
    {
      title: 'Experienced',
      path: '/experienced',
      cName: 'dropdown-link'
    }
  ];
  export default Menuitem;